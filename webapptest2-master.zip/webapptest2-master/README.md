webapptest2
==========

Test for interviews

This test is designed to give an overview of your capabilities as a C# developer.  The ultimate goal of the test is spelled out in the main method of Program.cs.

Implement the TODO comments to the best of your ability.  In addition, you should be looking at how to improve this program.  The DatabaseUtil class should not need to be significantly refactored, although you may do so as long as you do not destroy it's functionality.

You can download this project, make your changes, zip/tar it up and send it along with your resume, or if you want to impress us, fork it, put your changes in, and send along the url.

This test should take less than an hour.  You WILL be given another (quite different) test if you interview here, so please don't bother cheating.


Thank you,
Rob Conklin 
